package com.pawana.student;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootApplication
@EnableWebSecurity
public class StudentInfoApplication extends WebSecurityConfigurerAdapter{
	
	@Autowired
	private DataSource dataSource;
	
	private String USER_CHK = "SELECT emailId,password FROM USER WHERE emailId=?";
	private String ROLE_CHK = "SELECT r.* FROM USER u,ROLE r, USER_ROLE ur "
			+ "WHERE u.emailId=ur.emailId and r.roleId=ur.roleId and u.emailId=?";

	public static void main(String[] args) {
		SpringApplication.run(StudentInfoApplication.class, args);
	}
	
	@Bean
	public BCryptPasswordEncoder encode() {
		return new BCryptPasswordEncoder();
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests().antMatchers("/login").permitAll().
		antMatchers("/signup").permitAll().
		antMatchers("/registration").permitAll().and().
		formLogin().loginPage("/auth").failureForwardUrl("/failure").defaultSuccessUrl("/home/**").
		usernameParameter("emailId").passwordParameter("password").permitAll();
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.jdbcAuthentication().dataSource(dataSource).
		usersByUsernameQuery(USER_CHK).
		authoritiesByUsernameQuery(ROLE_CHK).passwordEncoder(encode());
	}

}
