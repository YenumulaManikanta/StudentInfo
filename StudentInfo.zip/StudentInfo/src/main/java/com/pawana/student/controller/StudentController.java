package com.pawana.student.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.pawana.student.Lo.StudentLo;
import com.pawana.student.service.AuthService;
import com.pawana.student.vo.StudentVO;
import com.pawana.student.vo.User;

@Controller
public class StudentController {
	
	private static final String SIGNUP = "signup";
	
	@Autowired
	AuthService authService;
	
	@GetMapping("/login")
	public String login(Model model) {
			
			model.addAttribute("login", new User());
		
		return "login";
	}
	
	@GetMapping("/signup")
	public String signup(Model model) {
		System.err.println("in signup method---------"+authService.roleInfo());
		model.addAttribute("roleinfo", authService.roleInfo());
	
		model.addAttribute("userInfo", new User());
		
		return SIGNUP;
	}
	
	@PostMapping("/registration")
	public String registration(Model model,@ModelAttribute("userInfo") User user) {
		authService.saveUser(user);
		return SIGNUP;
	}

}
