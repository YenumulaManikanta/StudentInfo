package com.pawana.student.vo;

public class StudentVO {
	
	private String fname;
	@Override
	public String toString() {
		return "StudentVO [fname=" + fname + ", lname=" + lname + ", email=" + email + ", phone=" + phone + "]";
	}
	private String lname;
	private String email;
	private String phone;
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

}
