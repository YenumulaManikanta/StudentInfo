package com.pawana.student.service;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pawana.student.vo.Role;
import com.pawana.student.vo.User;

@Service
public class AuthService {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	BCryptPasswordEncoder encode;
	
	public List<Role> roleInfo(){
		
		return jdbcTemplate.query("select * from role", new RoleMapper());
	}
	
	@Transactional(rollbackFor = Exception.class)
	public boolean saveUser(User user) {
		
		Object obj[] = {user.getFirstName(),user.getLastName(),user.getPhone(),user.getEmailId(),encode.encode(user.getPassword())};
		
		boolean userFlag =  jdbcTemplate.update("INSERT INTO USER VALUES(?,?,?,?,?)",obj)>0;
		Object userRoleobj[] = {user.getEmailId(),user.getRoleId()};
		boolean roleFlag =  jdbcTemplate.update("INSERT INTO USER_ROLE VALUES(?,?)",userRoleobj)>0;
		
		return userFlag && roleFlag;
		
		
	}
	
	public class RoleMapper implements RowMapper<Role>{

		@Override
		public Role mapRow(ResultSet rs, int rowNum) throws SQLException {
			System.err.println(rs.getInt("roleId"));
			return new Role(rs.getInt("roleId"),rs.getString("roleName"));
		}

	
		
	}

}
